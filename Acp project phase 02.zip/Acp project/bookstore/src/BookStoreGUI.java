import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.ActionListener;
import java.sql.*;

class BookStoreGUI{
    private static final String ADMIN_PASSWORD = "admin1";
    private static JFrame mainFrame;

    public static void main(String[] args){
        createMainFrame();
    }

    private static void createMainFrame(){
        if(mainFrame==null){
            mainFrame=new JFrame("Bookshop Management System");
            mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            mainFrame.setSize(800, 500);
            mainFrame.setLocationRelativeTo(null);
        }
        mainFrame.getContentPane().removeAll();

        JPanel mainPanel=new JPanel(new BorderLayout(20, 20));
        mainPanel.setBorder(new EmptyBorder(20, 20, 20, 20));

        JLabel headingLabel=new JLabel("Welcome to Bookshop Management System", SwingConstants.CENTER);
        headingLabel.setFont(new Font("Arial", Font.BOLD, 22));
        headingLabel.setForeground(Color.BLACK);

        JPanel buttonPanel=new JPanel(new GridLayout(1, 3, 20, 0));
        buttonPanel.setBorder(new EmptyBorder(20, 0, 0, 0));

        JButton adminButton = createStyledButton("Admin");
        JButton customerButton = createStyledButton("Customer");
        JButton exitButton = createStyledButton("Exit");

        adminButton.addActionListener(e -> authenticateAdmin());
        customerButton.addActionListener(e -> showCustomerMenu());
        exitButton.addActionListener(e -> System.exit(0));

        buttonPanel.add(adminButton);
        buttonPanel.add(customerButton);
        buttonPanel.add(exitButton);

        mainPanel.add(headingLabel, BorderLayout.NORTH);
        mainPanel.add(buttonPanel, BorderLayout.CENTER);

        mainFrame.add(mainPanel);
        mainFrame.revalidate();
        mainFrame.repaint();
        mainFrame.setVisible(true);
    }
    private static JButton createStyledButton(String text) {
        JButton button = new JButton(text);
        button.setFont(new Font("Arial", Font.PLAIN, 18));
        button.setFocusPainted(false);
        button.setBackground(new Color(173, 216, 230));
        button.setForeground(Color.BLACK);
        button.setBorder(BorderFactory.createLineBorder(new Color(100, 149, 237), 2));
        button.setCursor(new Cursor(Cursor.HAND_CURSOR));
        return button;
    }
    private static void authenticateAdmin() {
        String password = JOptionPane.showInputDialog(mainFrame, "Enter Admin Password:", "Authentication", JOptionPane.PLAIN_MESSAGE);

        if(password!=null && password.equals(ADMIN_PASSWORD)){
            showAdminMenu();
        }else if(password!=null){
            JOptionPane.showMessageDialog(mainFrame, "Incorrect password. Returning to main menu.", "Error", JOptionPane.ERROR_MESSAGE);
            createMainFrame();
        }
    }
    private static void showAdminMenu(){
        JPanel panel=new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        panel.add(createMenuLabel("Admin Panel"));

        String[] options = {"Add Book", "Search Book", "Update Book", "Show All Books", "Add Quantity", "Delete Book", "Exit"};
        for (String option : options) {
            JButton button = createStyledButton(option);
            button.addActionListener(createAdminActions(option));
            panel.add(button);
        }

        showPanel(panel);
    }
    private static void showCustomerMenu() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBorder(new EmptyBorder(20, 20, 20, 20));

        panel.add(createMenuLabel("Customer Panel"));

        String[] options = {"Search Book", "Show All Books", "Buy Book", "Exit"};
        for (String option : options) {
            JButton button = createStyledButton(option);
            button.addActionListener(createCustomerActions(option));
            panel.add(button);
        }

        showPanel(panel);
    }
    private static JLabel createMenuLabel(String text) {
        JLabel label = new JLabel(text, SwingConstants.CENTER);
        label.setFont(new Font("Arial", Font.BOLD, 20));
        label.setForeground(Color.BLACK);
        label.setBorder(new EmptyBorder(10, 0, 20, 0));
        return label;
    }
    private static ActionListener createAdminActions(String action) {
        return e -> {
            switch (action) {
                case "Add Book" -> addBook();
                case "Search Book" -> searchBook();
                case "Update Book" -> updateBook();
                case "Show All Books" -> showBooks();
                case "Add Quantity" -> addQuantity();
                case "Delete Book" -> deleteBook();
                case "Exit" -> createMainFrame();
            }
        };
    }
    private static ActionListener createCustomerActions(String action) {
        return e -> {
            switch (action) {
                case "Search Book" -> searchBook();
                case "Show All Books" -> showBooks();
                case "Buy Book" -> buyBook();
                case "Exit" -> createMainFrame();
            }
        };
    }
    private static void showPanel(JPanel panel) {
        mainFrame.getContentPane().removeAll();
        mainFrame.getContentPane().add(panel);
        mainFrame.revalidate();
        mainFrame.repaint();
    }
    private static void addBook() {
        try (Connection connection = DBConnection.getConnection()) {
            int id = Integer.parseInt(JOptionPane.showInputDialog("Enter Book ID:"));
            String name = JOptionPane.showInputDialog("Enter Book Name:");
            String author = JOptionPane.showInputDialog("Enter Author Name:");
            float price = Float.parseFloat(JOptionPane.showInputDialog("Enter Book Price:"));
            int quantity = Integer.parseInt(JOptionPane.showInputDialog("Enter Quantity:"));

            PreparedStatement stmt = connection.prepareStatement("INSERT INTO books (id, b_name, a_name, price, quantity) VALUES (?, ?, ?, ?, ?)");
            stmt.setInt(1, id);
            stmt.setString(2, name);
            stmt.setString(3, author);
            stmt.setFloat(4, price);
            stmt.setInt(5, quantity);
            stmt.executeUpdate();

            JOptionPane.showMessageDialog(mainFrame, "Book added successfully!");
        } catch (Exception e) {
            JOptionPane.showMessageDialog(mainFrame, "Error adding book: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private static void searchBook() {
        try (Connection connection = DBConnection.getConnection()) {
            String searchTerm = JOptionPane.showInputDialog("Enter Book Name or ID:");
            PreparedStatement stmt = connection.prepareStatement("SELECT * FROM books WHERE b_name LIKE ? OR id = ?");
            stmt.setString(1, "%" + searchTerm + "%");
            stmt.setString(2, searchTerm);
            ResultSet resultSet = stmt.executeQuery();

            StringBuilder result = new StringBuilder("Search Results:\n");
            boolean found = false;
            while (resultSet.next()) {
                found = true;
                result.append("ID: ").append(resultSet.getInt("id"))
                        .append(", Name: ").append(resultSet.getString("b_name"))
                        .append(", Author: ").append(resultSet.getString("a_name"))
                        .append(", Price: ").append(resultSet.getFloat("price"))
                        .append(", Quantity: ").append(resultSet.getInt("quantity"))
                        .append("\n");
            }

            if (!found) result.append("No book found.");
            JOptionPane.showMessageDialog(mainFrame, result.toString());
        } catch (Exception e) {
            JOptionPane.showMessageDialog(mainFrame, "Error searching book: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private static void updateBook() {
        try (Connection connection = DBConnection.getConnection()) {
            int id = Integer.parseInt(JOptionPane.showInputDialog("Enter Book ID to Update:"));

            // Fetch existing book details
            PreparedStatement selectStmt = connection.prepareStatement("SELECT * FROM books WHERE id = ?");
            selectStmt.setInt(1, id);
            ResultSet resultSet = selectStmt.executeQuery();

            if (resultSet.next()) {
                // Existing details
                String currentName = resultSet.getString("b_name");
                String currentAuthor = resultSet.getString("a_name");
                float currentPrice = resultSet.getFloat("price");
                int currentQuantity = resultSet.getInt("quantity");

                // Prompt user with current details (allowing them to skip by pressing Enter)
                String newName = JOptionPane.showInputDialog("Enter New Book Name (Current: " + currentName + "):");
                String newAuthor = JOptionPane.showInputDialog("Enter New Author Name (Current: " + currentAuthor + "):");
                String newPriceStr = JOptionPane.showInputDialog("Enter New Price (Current: " + currentPrice + "):");
                String newQuantityStr = JOptionPane.showInputDialog("Enter New Quantity (Current: " + currentQuantity + "):");

                // Assign new values or retain current values if input is empty
                String updatedName = (newName == null || newName.trim().isEmpty()) ? currentName : newName;
                String updatedAuthor = (newAuthor == null || newAuthor.trim().isEmpty()) ? currentAuthor : newAuthor;
                float updatedPrice = (newPriceStr == null || newPriceStr.trim().isEmpty()) ? currentPrice : Float.parseFloat(newPriceStr);
                int updatedQuantity = (newQuantityStr == null || newQuantityStr.trim().isEmpty()) ? currentQuantity : Integer.parseInt(newQuantityStr);

                // Update book details in the database
                PreparedStatement updateStmt = connection.prepareStatement(
                        "UPDATE books SET b_name = ?, a_name = ?, price = ?, quantity = ? WHERE id = ?"
                );
                updateStmt.setString(1, updatedName);
                updateStmt.setString(2, updatedAuthor);
                updateStmt.setFloat(3, updatedPrice);
                updateStmt.setInt(4, updatedQuantity);
                updateStmt.setInt(5, id);
                updateStmt.executeUpdate();

                JOptionPane.showMessageDialog(mainFrame, "Book details updated successfully!");
            } else {
                JOptionPane.showMessageDialog(mainFrame, "Book not found!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(mainFrame, "Invalid input! Please enter valid details.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(mainFrame, "Error updating book: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private static void addQuantity() {
        try (Connection connection = DBConnection.getConnection()) {
            int id = Integer.parseInt(JOptionPane.showInputDialog("Enter Book ID to Add Quantity:"));
            int quantityToAdd = Integer.parseInt(JOptionPane.showInputDialog("Enter Quantity to Add:"));

            PreparedStatement stmt = connection.prepareStatement("UPDATE books SET quantity = quantity + ? WHERE id = ?");
            stmt.setInt(1, quantityToAdd);
            stmt.setInt(2, id);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(mainFrame, "Quantity added successfully!");
            } else {
                JOptionPane.showMessageDialog(mainFrame, "Book not found!");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(mainFrame, "Error adding quantity: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private static void deleteBook() {
        try (Connection connection = DBConnection.getConnection()) {
            int id = Integer.parseInt(JOptionPane.showInputDialog("Enter Book ID to Delete:"));

            PreparedStatement stmt = connection.prepareStatement("DELETE FROM books WHERE id = ?");
            stmt.setInt(1, id);

            int rowsAffected = stmt.executeUpdate();
            if (rowsAffected > 0) {
                JOptionPane.showMessageDialog(mainFrame, "Book deleted successfully!");
            } else {
                JOptionPane.showMessageDialog(mainFrame, "Book not found!");
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(mainFrame, "Error deleting book: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private static void buyBook() {
        try (Connection connection = DBConnection.getConnection()) {
            int id = Integer.parseInt(JOptionPane.showInputDialog("Enter Book ID to Buy:"));
            int quantityToBuy = Integer.parseInt(JOptionPane.showInputDialog("Enter Quantity to Buy:"));

            PreparedStatement checkStmt = connection.prepareStatement("SELECT b_name, a_name, price, quantity FROM books WHERE id = ?");
            checkStmt.setInt(1, id);
            ResultSet resultSet = checkStmt.executeQuery();

            if (resultSet.next()) {
                String bookName = resultSet.getString("b_name");
                String authorName = resultSet.getString("a_name");
                float price = resultSet.getFloat("price");
                int availableQuantity = resultSet.getInt("quantity");

                if (quantityToBuy > availableQuantity) {
                    JOptionPane.showMessageDialog(mainFrame, "Not enough stock available. Current stock: " + availableQuantity, "Error", JOptionPane.ERROR_MESSAGE);
                } else {
                    PreparedStatement updateStmt = connection.prepareStatement("UPDATE books SET quantity = quantity - ? WHERE id = ?");
                    updateStmt.setInt(1, quantityToBuy);
                    updateStmt.setInt(2, id);
                    updateStmt.executeUpdate();

                    float totalCost = quantityToBuy * price;
                    String billSummary = "Thank you for your purchase!\n\n"
                            + "----- Bill Summary -----\n"
                            + "Book Name: " + bookName + "\n"
                            + "Author: " + authorName + "\n"
                            + "Price per Book: Rs" + price + "\n"
                            + "Quantity: " + quantityToBuy + "\n"
                            + "Total Cost: Rs" + totalCost + "\n"
                            + "------------------------\n"
                            + "We hope you enjoy your reading experience!";

                    JOptionPane.showMessageDialog(mainFrame, billSummary, "Purchase Successful", JOptionPane.INFORMATION_MESSAGE);
                }
            } else {
                JOptionPane.showMessageDialog(mainFrame, "Book not found!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (Exception e) {
            JOptionPane.showMessageDialog(mainFrame, "Error buying book: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    private static void showBooks() {
        try (Connection connection = DBConnection.getConnection()) {
            PreparedStatement stmt = connection.prepareStatement("SELECT * FROM books");
            ResultSet resultSet = stmt.executeQuery();

            StringBuilder result = new StringBuilder("Books Available:\n");
            while (resultSet.next()) {
                result.append("ID: ").append(resultSet.getInt("id"))
                        .append(", Name: ").append(resultSet.getString("b_name"))
                        .append(", Author: ").append(resultSet.getString("a_name"))
                        .append(", Price: ").append(resultSet.getFloat("price"))
                        .append(", Quantity: ").append(resultSet.getInt("quantity"))
                        .append("\n");
            }

            JOptionPane.showMessageDialog(mainFrame, result.toString(), "Book List", JOptionPane.INFORMATION_MESSAGE);
        } catch (Exception e) {
            JOptionPane.showMessageDialog(mainFrame, "Error retrieving books: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
}
class DBConnection {
    public static Connection getConnection() throws SQLException {
        String url = "jdbc:mysql://localhost:3306/bookstore";
        String user = "root";
        String password = "";
        return DriverManager.getConnection(url, user, password);
    }
}